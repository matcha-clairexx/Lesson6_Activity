# Lesson 6 Activity - Polish and Protect the Student API

A single-file, GitHub-ready Lesson 6 reference solution. It demonstrates Laravel API resources, nested relationships, pagination, owner-only email fields, and rate limiting.

> **Integration note:** This is the Lesson 6 solution, not a complete Laravel application. Copy the code blocks into the indicated paths in your Lesson 5 Laravel project. That app should have Laravel Sanctum installed, a `Student` model related to `Course`, and users configured with Sanctum's `HasApiTokens` trait. Do not commit credentials, access tokens, or your `.env` file.

## Requirements

- Laravel 13.x (the version used in the lesson)
- Laravel Sanctum configured for API token authentication
- A `Student` model with `id`, `name`, `email`, `user_id`, and a `course` relationship
- A `Course` model with `id` and `name`
- A `User` model using `Laravel\Sanctum\HasApiTokens`

## 1. Create the API resources

Run these commands from the Laravel application:

```bash
php artisan make:resource StudentResource
php artisan make:resource CourseResource
```

### `app/Http/Resources/CourseResource.php`

```php
<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CourseResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
        ];
    }
}
```

### `app/Http/Resources/StudentResource.php`

```php
<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class StudentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->when(
                $request->user()?->id === $this->user_id,
                $this->email
            ),
            'course' => new CourseResource($this->whenLoaded('course')),
        ];
    }
}
```

Only the fields listed in each resource are exposed. `user_id` and timestamps are excluded. The email is included only when the authenticated user's ID matches the student owner's ID. `whenLoaded('course')` includes a course only when it was eager-loaded, and does not issue a query itself.

## 2. Add the paginated student endpoint

### `app/Http/Controllers/StudentController.php`

```php
<?php

namespace App\Http\Controllers;

use App\Http\Resources\StudentResource;
use App\Models\Student;

class StudentController extends Controller
{
    public function index()
    {
        return StudentResource::collection(
            Student::with('course')->paginate(10)
        );
    }
}
```

The `with('course')` eager-loads the relationship to avoid N+1 queries. Laravel's paginator adds `data`, `links`, and `meta` to the resource collection response.

The `Student` model should have a course relationship like this (adapt the related model and key if your schema differs):

```php
public function course()
{
    return $this->belongsTo(Course::class);
}
```

## 3. Define the named rate limiter

Merge this limiter into the existing `boot()` method in `app/Providers/AppServiceProvider.php`; do not replace unrelated provider logic.

```php
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;

public function boot(): void
{
    RateLimiter::for('students-api', function (Request $request) {
        return Limit::perMinute(60)
            ->by($request->user()?->id ?: $request->ip());
    });
}
```

Authenticated requests are counted by user ID; guests are counted by IP address.

## 4. Protect the routes

Merge these routes into `routes/api.php`. Keep your existing token-creation controller and action from Lesson 5 if they differ from the example below.

```php
<?php

use App\Http\Controllers\StudentController;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Route;

Route::post('/tokens/create', [TokenController::class, 'store'])
    ->middleware('throttle:5,1');

Route::middleware(['auth:sanctum', 'throttle:students-api'])
    ->get('/students', [StudentController::class, 'index']);
```

`throttle:5,1` allows five token-creation requests per minute. The sixth request in that window should receive HTTP `429 Too Many Requests`. The student endpoint requires a valid Sanctum token and uses the named 60-per-minute limiter.

### Optional sample token controller

If your Lesson 5 app does not already have a token-creation handler, this is a basic example for `app/Http/Controllers/TokenController.php`. It expects a user model with `HasApiTokens`, and returns a newly issued Sanctum token.

```php
<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TokenController extends Controller
{
    public function store(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        if (! Auth::attempt($credentials)) {
            return response()->json(['message' => 'Invalid credentials.'], 401);
        }

        $user = User::where('email', $credentials['email'])->firstOrFail();
        $token = $user->createToken('api-token')->plainTextToken;

        return response()->json(['token' => $token]);
    }
}
```

## Lesson 6 Activity answers

**Q1. Why return a resource instead of the model itself?**  
A resource is an explicit API contract. It controls which fields clients receive and prevents accidental exposure of database columns.

**Q2. What does `whenLoaded()` do if the course wasn't eager-loaded?**  
It omits the relationship from the response without querying for it. This helps the resource avoid causing N+1 queries.

**Q3. Why limit guests by IP but users by ID?**  
A guest has no authenticated user ID, so the IP address provides a practical client key. Authenticated requests are counted per user, so people sharing an IP do not share one user's request limit.

## Verify the activity

1. Request `GET /api/students` with a valid bearer token.
2. Confirm the response includes `data`, `links`, and `meta`.
3. Confirm student objects do not include `user_id`, `created_at`, or `updated_at`.
4. Confirm each loaded course object includes `id` and `name`.
5. Request a student owned by another user and confirm its `email` key is absent; the owner's token should see the email.
6. Send six requests to `POST /api/tokens/create` within one minute and confirm the sixth receives HTTP 429.

## License

MIT License. Copying these examples into your Lesson 5 application is permitted. Adapt this section to your course or repository requirements before publishing.
